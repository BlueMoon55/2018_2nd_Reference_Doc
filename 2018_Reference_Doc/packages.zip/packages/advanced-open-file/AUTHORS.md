# Original Authors
- [Rev087](https://github.com/rev087), author of
  [fancy-new-file](https://github.com/rev087/fancy-new-file).
- [Trudko](https://github.com/Trudko), author of the fancy-new-file fork
  [advanced-new-file](https://github.com/Trudko/advanced-new-file).
- [Osmose](https://github.com/Osmose/), author of the advanced-new-file fork
  [advanced-open-file](https://github.com/Osmose/advanced-open-file).

# Current Maintainers
- [Osmose](https://github.com/Osmose/)

# Contributors
- [JesseLeite](https://github.com/JesseLeite)
- [artagnon](https://github.com/artagnon)
- [itiut](https://github.com/itiut)
- [jhslinkman](https://github.com/jhslinkman)
- [AlexWayfer](https://github.com/AlexWayfer)
- [jacobmischka](https://github.com/jacobmischka)
- [lee-dohm](https://github.com/lee-dohm)
- [toumorokoshi](https://github.com/toumorokoshi)
- [econtal](https://github.com/econtal)
